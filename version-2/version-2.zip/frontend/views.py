from django.shortcuts import  render, get_object_or_404



# home for public articles views 
def index(request):
    return render(request,'home.html')

# login for users already exist
def login(request):
    return render(request, 'login.html')

# register 
def register(request):
    return render(request, 'register.html')
# editor dashboard 
def editor_dashboard(request):
    return render(request, 'dashboard/editor.html')
# editor dashboard 
def journalist_dashboard(request):
    return render(request, 'dashboard/journalist.html')

def article_detail(request, article_id):
    article = get_object_or_404( id=article_id)
    return render(request, 'Journalist/singleJournalistPage.html', {'article': article})